<?php
session_start();
include ('../include/actualisation_session.php'); // Session update
include ('../include/blocagepage_public.php'); // Blocking access to the page if not connected
header('Content-type: text/html; charset=utf-8');
require_once '../styleswitcher.php';

// Connection to the database
include ('../include/connectBDD.php');
?>

<?php
$new_pseudo = $_POST['new_pseudo'];
$old_password_user = $_POST['old_password_user'];
$new_password_user = $_POST['new_password_user'];
$new_password2_user = $_POST['new_password2_user'];
$new_mail_username = $_POST['new_mail_username'];

if(isset($_SESSION['username']) && isset($_SESSION['typeuser'])) { // I verify that the variable exists
    $req_user = $bdd->prepare("SELECT * FROM User WHERE id_user = ?"); // I select the user in the database
    $req_user->execute(array($_SESSION['username'])); // I execute the query
    $user = $req_user->fetch();

    if(isset($_POST['newpseudo_user']) AND !empty($_POST['newpseudo_user']) AND $_POST['newpseudo_user'] != $user['pseudo_user']) { // I verify that the value is not empty and different from the previous value
       $newpseudo = htmlspecialchars($_POST['newpseudo_user']); // I prevent SQL injection
       $insert_pseudo = $bdd->prepare("UPDATE User SET pseudo_user = ? WHERE id_user = ?"); // I update the User table, the WHERE clause ensures the update is for the specific id
       $insert_pseudo->execute(array($newpseudo, $_SESSION['username'])); // I execute the query
       header('Location: member_space.php?id='.$_SESSION['username']); // Redirect to the user profile
    }

    if(isset($_POST['newmail_username']) AND !empty($_POST['newmail_username']) AND $_POST['newmail_username'] != $user['mail_username']) { // I verify that the value is not empty and different from the previous value
       $newmail = htmlspecialchars($_POST['newmail_username']); // I prevent SQL injection
       $insert_mail = $bdd->prepare("UPDATE User SET mail_username = ? WHERE id_user = ?"); // I update the User table, the WHERE clause ensures the update is for the specific id
       $insert_mail->execute(array($newmail, $_SESSION['username'])); // I execute the query
       header('Location: member_space.php?id='.$_SESSION['username']); // Redirect to the user profile
    }

    if(isset($_POST['new_password_user']) AND !empty($_POST['new_password_user']) AND isset($_POST['new_password2_user']) AND !empty($_POST['new_password2_user'])) { // I verify that the values exist and are different from the previous value and that they are identical password=password2

       $password = password_hash($_POST['new_password_user'], PASSWORD_BCRYPT); // I secure the passwords with a hash
       $password2 = password_hash($_POST['new_password2_user'], PASSWORD_BCRYPT);
       if($password == $password2) {
         $insert_password = $bdd->prepare("UPDATE User SET password_user = ? WHERE id_user = ?"); // I update the User table with the password
         $insert_password->execute(array($password, $_SESSION['username'])); // I execute the query
         header('Location: profil.php?id='.$_SESSION['username']); // Redirect to the user profile
       }
       else {
          $message = "Your two passwords do not match!";
       }
    }
    if(isset($_POST['new_pseudo_user']) AND $_POST['new_pseudo_user'] == $user['pseudo_user']) { // If no change is made
      header('Location: profil.php?id='.$_SESSION['username']); // Redirect to the user profile
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Space</title>

    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../pol/index2.css">
    <link rel="stylesheet" media="screen, projection" type="text/css" href="../css/style.css">
</head>
<body>
    <!-- Body content goes here -->
</body>
</html>